<?php
$res = file_get_contents("https://upsara.com");
echo $res;