<?php
require_once 'config.php';
//Read a web page and check for errors:
$url = "https://www.upsara.com/" . basename($_SERVER['REQUEST_URI']);
$result = file_get_contents($url);
//$page = $result['content'];
//echo $page;
echo $result;